#pragma once
class MyObstacles
{

};

